# Promise
##教你一步一步实现一个promise
教程参见 博文 [手把手教你写一个完整的Promise] (http://www.cnblogs.com/huansky/p/6064402.html) 
