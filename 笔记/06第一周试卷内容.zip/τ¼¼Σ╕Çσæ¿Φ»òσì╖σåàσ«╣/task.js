while (true) {
    // var s = [];
    // s.push(Math.random());
    postMessage(Math.random());
}